const express = require("express");
const router = express.Router();
const {
  getItems,
  addItem,
  deleteItem,
  updateStock, // Import the new function
  updatePrice,
  updateDiscountedPrice,
  toggleAvailability,
  migrateAndCleanItems
} = require("../controllers/itemController");
const upload = require("../middleware/upload");
const protect = require("../middleware/authMiddleware");
const {
  validateItem,
  validateObjectId,
  validatePrice,
} = require("../middleware/validators");

router.get("/", getItems);
router.post("/", protect, upload.single("image"), validateItem, addItem);
router.delete("/:id", protect, validateObjectId, deleteItem);
router.patch("/:id/stock", protect, validateObjectId, updateStock); // New Route for updating stock
router.patch("/:id/price", protect, validateObjectId, validatePrice, updatePrice);
router.patch("/:id/discount", protect, validateObjectId, updateDiscountedPrice);
router.patch("/:id", protect, validateObjectId, toggleAvailability);
router.post("/optimize-db", protect, migrateAndCleanItems);

module.exports = router;